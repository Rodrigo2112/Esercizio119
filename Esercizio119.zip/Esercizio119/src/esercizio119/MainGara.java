/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package esercizio119;

/**
 *
 * @author informatica
 */
public class MainGara {
    public static int RUN = 0;
    public static void main (String[] args){
        Counter c1 = new Counter();
        Thread t1 = new Thread (c1,"Cavallo 1");
        t1.setPriority(1);
        
        Counter c2 = new Counter();
        Thread t2 = new Thread (c2,"Cavallo 2");
        t2.setPriority(5);
        
        Counter c3 = new Counter();
        Thread t3 = new Thread (c3,"Cavallo 3");
        t3.setPriority(1);
        
        t1.start();
        t2.start();
        t3.start();
       
        
        RUN = 1;
        
        try
        {
            Thread.sleep(5000);
        }catch(InterruptedException e){
            e.printStackTrace();
        }
        
        RUN = 2;
    }
}
